	- Swing GUI interface just for demo
	